# gsg-kicad-lib
GSG's schematic symbols and modules for KiCad
